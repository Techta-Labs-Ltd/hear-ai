import asyncio
import json
import os
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

from hear.audio.workspace import AudioWorkspace


async def convert_wav_file_to_mp3(
    wav_path: str,
    bitrate_kbps: int = 96,
    *,
    job_id: str | None = None,
    run_id: str | None = None,
    track_id: str | None = None,
    purpose: str = "mp3",
) -> str:
    mp3_path = wav_path + f"_{purpose}.mp3"
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(None, _convert_sync, wav_path, mp3_path, bitrate_kbps)
    source = probe_audio(wav_path)
    output = probe_audio(mp3_path)
    output_duration = float(output["duration_seconds"])
    source_duration = float(source["duration_seconds"])
    duration_delta = abs(output_duration - source_duration)
    tolerance = max(1.0, source_duration * 0.001)
    if duration_delta > tolerance:
        try:
            os.unlink(mp3_path)
        except OSError:
            pass
        raise RuntimeError(
            f"encoded audio duration mismatch: source={source['duration_seconds']:.3f}s, output={output['duration_seconds']:.3f}s"
        )
    return mp3_path


def _convert_sync(wav_path: str, mp3_path: str, bitrate_kbps: int) -> None:
    subprocess.run(
        ["ffmpeg", "-y", "-i", wav_path, "-b:a", f"{bitrate_kbps}k", mp3_path],
        capture_output=True,
        check=True,
    )


def probe_audio(path: str) -> dict[str, float | int | str]:
    completed = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration,size,bit_rate,format_name",
            "-of",
            "json",
            path,
        ],
        capture_output=True,
        check=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    audio_format = payload.get("format") or {}
    return {
        "duration_seconds": float(audio_format.get("duration") or 0.0),
        "size_bytes": int(audio_format.get("size") or os.path.getsize(path)),
        "bitrate_bps": int(audio_format.get("bit_rate") or 0),
        "format": str(audio_format.get("format_name") or ""),
    }


def delivery_bitrate_kbps(
    source_path: str, *, maximum_kbps: int = 96, reduction_ratio: float = 0.8
) -> int:
    """Choose an Alexa delivery bitrate without upscaling compressed input."""
    source = probe_audio(source_path)
    source_kbps = int(source["bitrate_bps"]) / 1000
    formats = set(str(source["format"]).split(","))
    if source_kbps <= 0 or formats.intersection({"wav", "aiff", "flac"}):
        return maximum_kbps
    target = min(maximum_kbps, int(source_kbps * reduction_ratio))
    ladder = (96, 80, 64, 56, 48, 40, 32, 24)
    return next((rate for rate in ladder if rate <= target), 24)


def save_as_mp3(
    audio,
    sample_rate: int,
    *,
    purpose: str = "mp3",
    bitrate_kbps: int = 96,
    workspace: AudioWorkspace | None = None,
) -> str:
    if isinstance(audio, torch.Tensor):
        audio_np = audio.detach().cpu().numpy()
    else:
        audio_np = np.asarray(audio)
    if audio_np.ndim == 1:
        audio_np = audio_np.reshape(1, -1)
    elif audio_np.ndim == 2 and audio_np.shape[0] > audio_np.shape[1]:
        audio_np = audio_np.T
    descriptor, wav_path = tempfile.mkstemp(
        prefix=f"{_safe_prefix(purpose)}-",
        suffix=".wav",
        dir=workspace.path if workspace is not None else None,
    )
    os.close(descriptor)
    mp3_path = wav_path + ".mp3"
    try:
        sf.write(wav_path, audio_np.T, sample_rate, format="WAV")
        _convert_sync(wav_path, mp3_path, bitrate_kbps)
    except BaseException:
        Path(wav_path).unlink(missing_ok=True)
        Path(mp3_path).unlink(missing_ok=True)
        raise
    Path(wav_path).unlink(missing_ok=True)
    return mp3_path


def _safe_prefix(value: str) -> str:
    prefix = "".join(character if character.isalnum() or character in "_.-" else "_" for character in value)
    return prefix[:48] or "audio"
