from __future__ import annotations

import gc
import importlib
import os
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch

from hear.execution.native import NativeExecutor
from hear.runtime.gpu_idle import AsyncIdleResource
from hear.utils.transcription_chunks import (
    adaptive_batch_size,
    append_shifted_result,
    finalize_combined_result,
    iter_audio_chunks,
)


@dataclass(frozen=True, slots=True)
class SpeechSegment:
    start: float
    end: float
    speaker: str = "UNKNOWN"


class LocalSileroVad:
    @staticmethod
    def _silero_vad_api():
        return importlib.import_module("silero_vad")

    def __init__(self, vad_onset: float, chunk_size: int) -> None:
        if not 0 < vad_onset < 1:
            raise ValueError("invalid_vad_onset")
        if chunk_size <= 0:
            raise ValueError("invalid_vad_chunk_size")
        self._vad_onset = vad_onset
        self._chunk_size = chunk_size
        vad = self._silero_vad_api()
        self._get_speech_timestamps = vad.get_speech_timestamps
        self._model = vad.load_silero_vad(onnx=False)

    @staticmethod
    def preprocess_audio(audio):
        return torch.from_numpy(np.asarray(audio, dtype=np.float32))

    @staticmethod
    def merge_chunks(segments, chunk_size, onset, offset):
        if chunk_size <= 0:
            raise ValueError("invalid_vad_chunk_size")
        if not segments:
            return []
        current_start = segments[0].start
        current_end = 0.0
        indexes: list[tuple[float, float]] = []
        merged: list[dict] = []
        for segment in segments:
            if segment.end - current_start > chunk_size and current_end - current_start > 0:
                merged.append(
                    {
                        "start": current_start,
                        "end": current_end,
                        "segments": indexes,
                    }
                )
                current_start = segment.start
                indexes = []
            current_end = segment.end
            indexes.append((segment.start, segment.end))
        merged.append(
            {
                "start": current_start,
                "end": current_end,
                "segments": indexes,
            }
        )
        return merged

    def __call__(self, audio, **kwargs):
        if int(audio["sample_rate"]) != 16000:
            raise ValueError("silero_vad_requires_16000hz")
        waveform = audio["waveform"]
        if isinstance(waveform, np.ndarray):
            waveform = torch.from_numpy(waveform.astype(np.float32, copy=False))
        waveform = waveform.float().reshape(-1)
        timestamps = self._get_speech_timestamps(
            waveform,
            self._model,
            threshold=self._vad_onset,
            sampling_rate=16000,
            max_speech_duration_s=float(self._chunk_size),
        )
        return [
            SpeechSegment(
                float(item["start"]) / 16000.0,
                float(item["end"]) / 16000.0,
            )
            for item in timestamps
        ]


class QwenAsrEngine:
    def __init__(
        self,
        *,
        model_path: Path,
        aligner_path: Path,
        cache_dir: Path,
        temp_dir: Path,
        dtype: str,
        device_map: str,
        vad_onset: float,
        vad_offset: float,
        max_batch_size: int,
        long_audio_batch_size: int,
        chunk_seconds: int,
    ) -> None:
        self._worker = NativeExecutor("qwen-asr")
        self._temp_dir = temp_dir
        self._max_batch_size = max_batch_size
        self._long_audio_batch_size = long_audio_batch_size
        self._chunk_seconds = chunk_seconds
        self._cuda_healthy = True
        whisperx = importlib.import_module("whisperx")
        load_qwen_asr_model = importlib.import_module("whisperx.asr_qwen").load_model
        self._whisperx = whisperx
        vad_model = LocalSileroVad(vad_onset, chunk_seconds)
        self._asr = load_qwen_asr_model(
            str(model_path),
            device="cuda",
            language="en",
            download_root=str(cache_dir),
            local_files_only=True,
            vad_model=vad_model,
            vad_options={
                "vad_onset": vad_onset,
                "vad_offset": vad_offset,
            },
            qwen_dtype=dtype,
            qwen_device_map=device_map,
            qwen_forced_aligner=str(aligner_path),
            max_inference_batch_size=max_batch_size,
        )
        wrapper = getattr(self._asr, "model", None)
        model = getattr(wrapper, "model", None)
        thinker = getattr(model, "thinker", None)
        generation = getattr(thinker, "generation_config", None)
        if generation is not None and generation.pad_token_id is None:
            generation.pad_token_id = 151643

    async def transcribe_window(
        self,
        samples: np.ndarray,
        batch_size: int,
        language: str,
    ) -> dict:
        if not isinstance(samples, np.ndarray) or samples.ndim != 1:
            raise ValueError("invalid_transcription_window")
        if not 0 < samples.size <= 600 * 16000:
            raise ValueError("invalid_transcription_window")
        if not np.isfinite(samples).all():
            raise ValueError("invalid_transcription_window")
        if not 1 <= batch_size <= self._max_batch_size:
            raise ValueError("invalid_transcription_batch")
        started = time.perf_counter()
        result = await self._worker.run(self._transcribe_window, samples, batch_size, language)
        elapsed = time.perf_counter() - started
        timings = result.setdefault("_runtime_timing", {})
        timings["executor_wait_seconds"] = max(0.0, elapsed - timings["model_window_seconds"])
        return result

    async def transcribe(self, audio_bytes: bytes, batch_size: int) -> dict:
        if len(audio_bytes) > 16 * 1024 * 1024:
            raise ValueError("reference_audio_too_large")
        return await self._worker.run(
            self._transcribe_bytes,
            audio_bytes,
            batch_size,
        )

    def _transcribe_window(
        self,
        samples: np.ndarray,
        batch_size: int,
        language: str,
    ) -> dict:
        try:
            started = time.perf_counter()
            with torch.inference_mode():
                result = self._asr.transcribe(
                    samples,
                    batch_size=batch_size,
                    language=language,
                )
            if not isinstance(result, dict) or not isinstance(result.get("segments"), list):
                raise RuntimeError("invalid_transcription_window_result")
            result["_runtime_timing"] = {"model_window_seconds": time.perf_counter() - started}
            return result
        except RuntimeError as exc:
            if "cuda" in str(exc).lower() or "out of memory" in str(exc).lower():
                self._cuda_healthy = False
            raise

    def _transcribe_bytes(self, audio_bytes: bytes, batch_size: int) -> dict:
        self._temp_dir.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(
            suffix=".wav",
            delete=False,
            dir=self._temp_dir,
        ) as stream:
            stream.write(audio_bytes)
            path = stream.name
        try:
            audio = self._whisperx.load_audio(path)
            duration = len(audio) / 16000
            effective_batch = adaptive_batch_size(
                duration,
                batch_size,
                self._long_audio_batch_size,
            )
            combined: dict[str, Any] = {
                "segments": [],
                "language": "en",
                "audio_duration": duration,
            }
            for offset, chunk in iter_audio_chunks(
                audio,
                sample_rate=16000,
                chunk_seconds=self._chunk_seconds,
            ):
                result = self._transcribe_window(
                    chunk,
                    effective_batch,
                    "en",
                )
                append_shifted_result(
                    combined,
                    result,
                    offset_seconds=offset,
                )
            return finalize_combined_result(combined)
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass

    def check_health(self) -> None:
        if not self._cuda_healthy:
            raise RuntimeError("qwen_asr_cuda_unhealthy")

    async def close(self) -> None:
        await self._worker.close()
        if hasattr(self, "_asr"):
            del self._asr
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()


class LazyQwenAsrEngine:
    """Load Qwen ASR on the first job and evict it after the configured idle TTL."""

    def __init__(
        self,
        *,
        model_path: Path,
        aligner_path: Path,
        cache_dir: Path,
        temp_dir: Path,
        dtype: str,
        device_map: str,
        vad_onset: float,
        vad_offset: float,
        max_batch_size: int,
        long_audio_batch_size: int,
        chunk_seconds: int,
        idle_seconds: float,
        eviction_enabled: bool,
    ) -> None:
        self._model_path = model_path
        self._aligner_path = aligner_path
        self._cache_dir = cache_dir
        self._temp_dir = temp_dir
        self._dtype = dtype
        self._device_map = device_map
        self._vad_onset = vad_onset
        self._vad_offset = vad_offset
        self._max_batch_size = max_batch_size
        self._long_audio_batch_size = long_audio_batch_size
        self._chunk_seconds = chunk_seconds
        self._loader = NativeExecutor("qwen-asr-lazy-loader")
        self._resource = AsyncIdleResource(
            "qwen_asr",
            self._load,
            self._close_loaded,
            idle_seconds=idle_seconds,
            eviction_enabled=eviction_enabled,
        )

    async def _load(self) -> QwenAsrEngine:
        return await self._loader.run(
            lambda: QwenAsrEngine(
                model_path=self._model_path,
                aligner_path=self._aligner_path,
                cache_dir=self._cache_dir,
                temp_dir=self._temp_dir,
                dtype=self._dtype,
                device_map=self._device_map,
                vad_onset=self._vad_onset,
                vad_offset=self._vad_offset,
                max_batch_size=self._max_batch_size,
                long_audio_batch_size=self._long_audio_batch_size,
                chunk_seconds=self._chunk_seconds,
            )
        )

    @staticmethod
    async def _close_loaded(engine: QwenAsrEngine) -> None:
        await engine.close()

    async def warmup(self) -> None:
        await self._resource.acquire()
        await self._resource.release()

    async def transcribe_window(self, samples: np.ndarray, batch_size: int, language: str) -> dict:
        engine = await self._resource.acquire()
        try:
            return await engine.transcribe_window(samples, batch_size, language)
        finally:
            await self._resource.release()

    async def transcribe(self, audio_bytes: bytes, batch_size: int) -> dict:
        engine = await self._resource.acquire()
        try:
            return await engine.transcribe(audio_bytes, batch_size)
        finally:
            await self._resource.release()

    def check_health(self) -> None:
        if self._resource.state == "failed":
            raise RuntimeError("qwen_asr_lazy_engine_failed")
        if not self._model_path.is_dir() or not self._aligner_path.is_dir():
            raise RuntimeError("qwen_asr_assets_missing")
        if not torch.cuda.is_available():
            raise RuntimeError("qwen_asr_cuda_unavailable")

    @property
    def lifecycle(self) -> dict:
        return self._resource.snapshot

    async def evict_now(self) -> bool:
        return await self._resource.evict_now()

    async def close(self) -> None:
        try:
            await self._resource.close()
        finally:
            await self._loader.close()
