#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bazel_bin="${HEAR_BAZEL_BIN:-bazel}"
if ! command -v "$bazel_bin" >/dev/null && [[ -x /root/.local/bin/bazel ]]; then
  bazel_bin=/root/.local/bin/bazel
fi
"$bazel_bin" build //:image_context //:runpod_image
exec "$bazel_bin" run //:runpod_image -- --target runpod-stack --tag hear-ai:production "$@"
