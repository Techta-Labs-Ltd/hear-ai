#!/usr/bin/env bash
set -euo pipefail

project_root="${BUILD_WORKSPACE_DIRECTORY:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
env_file="${HEAR_PRODUCTION_ENV_FILE:-/root/hear-ai-config/production.env}"
model_root="${HEAR_MODEL_ROOT_OVERRIDE:-/models}"
runtime_root="${HEAR_RUNTIME_ROOT:-/root/hear-ai-runtime}"
fish_source="${FISH_SPEECH_HOME_OVERRIDE:-/opt/fish-speech}"

[[ -f "$env_file" ]] || { echo "Production env missing: $env_file" >&2; exit 1; }
mkdir -p "$model_root" "$runtime_root/scratch"
cd "$project_root"

setup_role() {
  local role="$1"
  FISH_SPEECH_HOME="$fish_source" python3.12 scripts/setup_runtime.py --role "$role" --provider pod --no-dev
}

setup_role pipeline
setup_role magic_clean_natural

fish_approved="${HEAR_FISH_LICENSE_APPROVED:-false}"
if [[ "$fish_approved" == "true" ]]; then
  if [[ ! -d "$fish_source/.git" ]]; then
    git clone https://github.com/groxaxo/fish-speech-int4-patch.git "$fish_source"
  fi
  git -C "$fish_source" fetch --depth 1 origin fc4e1e24ff3b8d7d28fdd66e6789f23acb63c5bb
  git -C "$fish_source" checkout --detach fc4e1e24ff3b8d7d28fdd66e6789f23acb63c5bb
  setup_role reconstruction
fi

UV_PROJECT_ENVIRONMENT=/opt/hear-ai-v11/venvs/sound_cleanup_provisioning uv sync --project deploy/runtime --locked --no-default-groups --group sound-cleanup-provisioning
uv pip install --python /opt/hear-ai-v11/venvs/sound_cleanup_provisioning/bin/python "huggingface-hub>=0.24,<1" "silero-vad==6.2.1"

export HF_HUB_OFFLINE=0
export TRANSFORMERS_OFFLINE=0
export HF_DATASETS_OFFLINE=0

/opt/hear-ai-v11/venvs/pipeline/bin/python -m hear.tools.model_provisioning --role pipeline --model-root "$model_root" --cache-dir "$runtime_root/model-cache"

python3.12 scripts/provision_magic_clean_models.py --model-root "$model_root" --engine deepfilter

/opt/hear-ai-v11/venvs/sound_cleanup_provisioning/bin/python scripts/provision_release_sound_assets.py --model-root "$model_root"

if [[ "$fish_approved" == "true" ]]; then
  /opt/hear-ai-v11/venvs/reconstruction/bin/python -m scripts.provision_fish_nf4 --model-root "$model_root"
fi

if [[ "${HEAR_PROVISION_ONLY:-false}" == "true" ]]; then
  echo "HEAR_PRODUCTION_PROVISIONING_COMPLETE"
  exit 0
fi

export HEAR_ENV_FILE="$env_file"
export HEAR_ENV_PARSER_PYTHON=/opt/hear-ai-v11/venvs/pipeline/bin/python
export HEAR_FISH_LICENSE_APPROVED="$fish_approved"
exec bash "$project_root/scripts/run_pod_stack.sh"
